﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using SampleApplication.Domain;
using Microsoft.EntityFrameworkCore;

namespace SampleApplication.Infrastructure
{
    public class ProductRepository : IProductRepository
    {
        private readonly EntityFrameworkCoreDbContext _context;

        public ProductRepository(EntityFrameworkCoreDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public IList<Product> FindByBrandOrDescription(string brandOrDescription)
        {
            return _context.Products
                        .Where(p => EF.Functions.Like(p.Brand, $"%{brandOrDescription}%") || 
                               EF.Functions.Like(p.Description, $"%{brandOrDescription}%"))
                        .ToList();
        }

        public Product FindById(int productId)
        {
            return _context.Products.SingleOrDefault(p => p.ProductId == productId);
        }
    }
}
