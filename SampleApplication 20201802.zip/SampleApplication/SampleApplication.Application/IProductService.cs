﻿using System;
using System.Collections.Generic;
using SampleApplication.Dto;

namespace SampleApplication.Application
{
    public interface IProductService
    {
        IList<ProductDto> Find(SearchDto searchDto);
    }
}