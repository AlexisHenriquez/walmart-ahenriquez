﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleApplication.Application
{
    public class Constants
    {
        public const double DiscountRate = 0.5;

        public const int MinLengthSearchTerm = 4;
    }
}