﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SampleApplication.Dto
{
    public class SearchDto
    {
        public SearchDto()
        {
            Products = new List<ProductDto>();
        }

        [Required]
        public string Value { get; set; }

        public IList<ProductDto> Products { get; set; }
    }
}