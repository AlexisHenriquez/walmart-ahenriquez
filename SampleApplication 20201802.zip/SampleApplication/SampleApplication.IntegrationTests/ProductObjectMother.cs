﻿using System;
using System.Collections.Generic;
using System.Text;
using SampleApplication.Domain;

namespace SampleApplication.IntegrationTests
{
    internal class ProductObjectMother
    {
        internal IList<Product> GetListForGetProductsByBrandOrDescription(string brandOrDescription, int expected)
        {
            IList<Product> result = new List<Product>();

            for (int i = 0; i < expected; i++)
            {
                result.Add(new Product() { Brand = brandOrDescription, Description = brandOrDescription, ProductId = i });
            }

            return result;
        }
    }
}
