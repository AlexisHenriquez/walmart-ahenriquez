﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Moq;
using SampleApplication.Application;
using SampleApplication.Domain;
using SampleApplication.Dto;
using Xunit;

namespace SampleApplication.IntegrationTests
{
    public class ProductServiceShould
    {

        [Theory]
        [InlineData(5, "peuoooypt")]
        [InlineData(8, "sfzkvoñ")]
        [InlineData(11, "iñmfdpd")]
        [InlineData(14, "dcc gdodkñg")]
        [InlineData(17, "cni tñcapdx")]
        public void GetProductById(int productId, string expectedBrand)
        {
            SearchDto searchDto = new SearchDto() { Value = productId.ToString() };

            Mock<IProductRepository> productRepository = new Mock<IProductRepository>();

            productRepository
                .Setup(m => m.FindById(It.IsAny<int>()))
                .Returns(new Product() { Brand = expectedBrand, ProductId = productId });

            IProductService sut = new ProductService(productRepository.Object,
                new ProductDomainService(),
                new ProductFactory());

            searchDto.Products = sut.Find(searchDto);

            Assert.Equal(1, searchDto.Products.Count);

            Assert.Equal(expectedBrand, searchDto.Products.First().Brand);
        }

        [Theory]
        [InlineData(101)]
        [InlineData(181)]
        [InlineData(88)]
        [InlineData(99)]
        [InlineData(111)]
        [InlineData(222)]
        public void GetProductByIdWithDiscount(int productId)
        {
            SearchDto searchDto = new SearchDto() { Value = productId.ToString() };

            Mock<IProductRepository> productRepository = new Mock<IProductRepository>();

            productRepository
                .Setup(m => m.FindById(It.IsAny<int>()))
                .Returns(new Product() { Price = 100.0, ProductId = productId });

            IProductService sut = new ProductService(productRepository.Object,
                new ProductDomainService(),
                new ProductFactory());

            searchDto.Products = sut.Find(searchDto);

            Assert.Equal(1, searchDto.Products.Count);

            Assert.True(searchDto.Products.First().OriginalPrice > searchDto.Products.First().PriceWithDiscount);
        }

        [Theory]
        [InlineData(10)]
        [InlineData(18)]
        [InlineData(87)]
        [InlineData(98)]
        [InlineData(12)]
        [InlineData(332)]
        public void GetProductByIdWithoutDiscount(int productId)
        {
            SearchDto searchDto = new SearchDto() { Value = productId.ToString() };

            Mock<IProductRepository> productRepository = new Mock<IProductRepository>();

            productRepository
                .Setup(m => m.FindById(It.IsAny<int>()))
                .Returns(new Product() { Price = 100.0, ProductId = productId });

            IProductService sut = new ProductService(productRepository.Object,
                new ProductDomainService(),
                new ProductFactory());

            searchDto.Products = sut.Find(searchDto);

            Assert.Equal(1, searchDto.Products.Count);

            Assert.True(searchDto.Products.First().OriginalPrice == searchDto.Products.First().PriceWithDiscount);
        }

        [Theory]
        [InlineData("crrñ", 2)]
        [InlineData("cni", 0)]
        [InlineData("ikpxo", 3)]
        public void GetProductsByBrandOrDescription(string brandOrDescription, int expected)
        {
            SearchDto searchDto = new SearchDto() { Value = brandOrDescription };

            Mock<IProductRepository> productRepository = new Mock<IProductRepository>();

            productRepository
                    .Setup(m => m.FindByBrandOrDescription(It.IsAny<string>()))
                    .Returns(new ProductObjectMother().GetListForGetProductsByBrandOrDescription(brandOrDescription, expected));

            IProductService sut = new ProductService(productRepository.Object,
                new ProductDomainService(),
                new ProductFactory());

            searchDto.Products = sut.Find(searchDto);

            Assert.Equal(expected, searchDto.Products.Count);
        }
    }
}